tincr
=====