var logMessage = function(){};
var logError = function(){};