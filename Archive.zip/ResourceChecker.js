
var matchedUrls = {};
var navListenerRegistered = false;

var checkResources = function(callback){
	matchedUrls = {};
	
	var confirmResourceContent = function(resource){
		resource.getContent(function(content){
			backgroundMsgSupport.checkResourceContent(resource.url, content, function(data){
				if (data.success){
					logMessage(data.msg);
					matchedUrls[resource.url] = true;
				}
				else{
					logError(data.msg);
				}
			});
		});
	};
	
	chrome.devtools.inspectedWindow.getResources(function(resources){
		backgroundMsgSupport.checkResources(resources, function(data){
			for (var i = 0; i < data.length; i++){
				if (data[i]){
					//var resource = ;
					confirmResourceContent(resources[i]);
				}
			}
		});
	});
}
var registerNavListener = function(){
	if (!navListenerRegistered){
		chrome.devtools.network.onNavigated.addListener(function(){
			console.log('page navigated');
			backgroundMsgSupport.pageChanged(function(){
				checkResources();
			});
		});
	}
	navListenerRegistered = true;
}
chrome.devtools.inspectedWindow.onResourceContentCommitted.addListener(function(resource, content){
	if (matchedUrls[resource.url]){
		backgroundMsgSupport.updateResource(resource.url, content);
	}
});